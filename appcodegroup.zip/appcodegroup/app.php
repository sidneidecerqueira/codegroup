<?php
session_start();
session_cache_expire(620);
require_once 'app2/AppConfig.php';
require_once DIR_APP .'lib/HTML_Template_IT-1.3.0/HTML/Template/IT.php';
require_once DIR_APP .'app/models/Model.php';
require_once DIR_APP .'app/controllers/Controller.php';
require_once DIR_APP .'app/core/session.php';
class Init
{		
	function __construct()
	{		
		$tpl = new HTML_Template_IT(DIR_APP .'app/views');	
		$tpl->loadTemplatefile('app.tpl.htm', true, true);	
		$session = new SecureSessionHandler('uniapp');
		$session->start();
		
		$c_action = "ClientesController";
		$m_action = "index";
		
		if(!empty($_GET['c']) and !empty($_GET['m']))
		{
			$c_action = $_GET['c'];
			$m_action = $_GET['m'];			
		}
		require_once DIR_APP ."app/controllers/". $c_action .".php";
		$obj = new $c_action;
		$act = $obj->$m_action();
		
		if(isset($obj->titulopage))
		$tpl->setVariable('TITULO',$obj->titulopage);
					
		if (!$this->isXmlHttpRequest())
		{		
			$tpl->setVariable('DATA', $act);				
			$tpl->show();
		}
	}
	
	function isXmlHttpRequest()
	{
		$isAjax = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? $_SERVER['HTTP_X_REQUESTED_WITH'] : null;
		return (strtolower($isAjax) === 'xmlhttprequest');
	}

}

//Inicializa a aplica��o
$o= new Init();


