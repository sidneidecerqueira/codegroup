; <?php DO NOT REMOVE THIS LINE

[DB]

pg1 = pgsql://si:S4r4dsg6s2fFfeR@200.144.92.25/postgres
pg2 = pgsql://postgres:497168@localhost/postgres
my1 = mysql://root:@localhost:85/sead

[SESSION]
name = PROEC

; DO NOT REMOVE THIS LINE ?>
