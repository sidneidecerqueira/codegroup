<?php
/**
 * Description of Formulario
 *
 */
 
 // Caminho para a raiz
define( 'ABSPATH', $_SERVER['DOCUMENT_ROOT'] );
 
// Caminho para o diretório models
define( 'DIR_MODELS', ABSPATH.'/models/' );

// Caminho para O diretório controllers
define( 'DIR_CONTROLLERS', ABSPATH.'/controllers/' );

// Caminho para O diretório controllers
define( 'DIR_CLASS', ABSPATH.'/class/' );

// Caminho para O diretório controllers
define( 'DIR_APP', ABSPATH.'/app2/' );
 

 

?>
