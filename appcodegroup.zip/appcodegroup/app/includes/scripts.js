

function cad()
{
	var cad = true;
	$("#frm_cliente input[required]").each(function(index, value) {
	   if(!$( this ).val())
	   {
		   $( this ).addClass("is-invalid");	  
		   cad = false;
	   }
	  
	});	
	if(cad == false)
	{
		alert("Preencha corretamente os campos obrigatórios!");
	}
	else if(cad == true)
	{
		var $form = $("#frm_cliente");
		var values = $form.serialize();
		var jqxhr = $.ajax({
			type: 'POST',       
			//url: url,
			url: '?c=ClientesController&m=cadastrar_cliente_bd',
			data: values,
			dataType: 'html',
			context: document.body,
			global: false,
			async:false,
			success: function(data) {
				return data;
			}
		}).responseText;
		
		alert(jqxhr);
		window.location = 'app.php';
	}		
}

function edt()
{
	var edt = true;
	$("#frm_cliente_edt input[required]").each(function(index, value) {
	   if(!$( this ).val())
	   {
		   $( this ).addClass("is-invalid");	  
		   edt = false;
	   }
	  
	});	
	if(edt == false)
	{
		alert("Preencha corretamente os campos obrigatórios!");
	}
	else if(edt == true)
	{
		var $form = $("#frm_cliente_edt");
		var values = $form.serialize();
		var jqxhr = $.ajax({
			type: 'POST',       
			//url: url,
			url: '?c=ClientesController&m=editar_cliente_bd',
			data: values,
			dataType: 'html',
			context: document.body,
			global: false,
			async:false,
			success: function(data) {
				return data;
			}
		}).responseText;
		
		alert(jqxhr);
		window.location = 'app.php';
	}	
}
function exl()
{
	if(confirm("Deseja realmente exluir o registor?"))
	{
		var $form = $("#frm_cliente_edt");
		var values = $form.serialize();
		var jqxhr = $.ajax({
			type: 'POST',       
			//url: url,
			url: '?c=ClientesController&m=excluir_cliente_bd',
			data: values,
			dataType: 'html',
			context: document.body,
			global: false,
			async:false,
			success: function(data) {
				return data;
			}
		}).responseText;
		
		alert(jqxhr);
		window.location = 'app.php';
	}
}


