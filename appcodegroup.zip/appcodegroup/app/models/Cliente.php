﻿<?php
class Cliente extends Model
{
	var $template;
	
	
	function __construct()
	{
		
	}
	function prepare_cli_ins($dados)
	{
		$pdo = $this->prepare_pdo_db();
		$statement = $pdo->prepare("INSERT INTO cliente (nome, cpf, email, tel, endereco) VALUES (?, ?, ?, ?, ?)");
		if(!$statement->execute($dados))
		{
			$err = $statement->errorInfo();	
			$this->ret_prepare = $err[2];	
		}
		else 
		{
			$this->ret_prepare = "Dados cadastrados!";
		}
	}
	function prepare_cli_upd($dados)
	{
		$pdo = $this->prepare_pdo_db();
		$upd = $pdo->prepare("UPDATE cliente SET nome=:nome, cpf=:cpf, email=:email, tel=:tel, endereco=:endereco WHERE id=:id");
		if(!$upd->execute($dados))
		{
			$err = $upd->errorInfo();	
			$this->ret_prepare = $err[2];	
		}
		else 
		{
			$this->ret_prepare = "Dados atualizados!";
		}
	}
	function prepare_cli_del($dados)
	{
		$model = new Model();	 	
		if(!$model->pgdel("cliente",array("id"=>$dados['id'])))
		{
			$this->ret_prepare = "Erro ao excluir o registro!";	
		}
		else 
		{
			$this->ret_prepare = "Dados excluídos!";
		}
	}
	function lista_cli_all($limit,$offset)
	{
		if(!$limit)
		$limit=5;
		if(!$offset or $offset==1)
		$offset=0;
		
		$sql = "select *,to_char(dt_cadastro,'dd/mm/yyyy HH24:MI:SS') as dt_cadastro_br
										from cliente 
										order by id desc
										limit $limit offset $offset";
		$model = new Model();	 	
		$clientes = $model->pgquery($sql);
		return $clientes;
	}
	function c_cli_all()
	{
		$sql = "select count(*) as total from cliente";
		$model = new Model();	 	
		$exe = $model->pgquery($sql);
		return $exe[0]['total'];
	}
}