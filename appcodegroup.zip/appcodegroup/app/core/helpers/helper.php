<?php

class Helper
{

	function sendMail($to, $subject, $body, $from = '', $reply = '') 
	{
			($from) ? $from = $from : $from = 'PRÓ-REITORIA DE EXTENSÃO E CULTURA <no-reply.sead@unifesp.br>';
			($reply) ? $reply = $reply : $reply = 'Proec-Pibex';
			($subject) ? $subject = $subject : $subject = 'Proec-Pibex';
			//$headers = "Content-type: text/html; charset=UTF-8\r\n";
			//$headers .= "From: $from" . "\r\n" . "Reply-To: $reply" . "\r\n" . 'X-Mailer: PHP/' . phpversion();
			
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type: text/html; charset=iso-8859-1" . "\r\n";
			$headers .= "From: Proec-Pibex" . "\r\n" .
			"Reply-To: sead@unifesp.br" . "\r\n" .
			"X-Mailer: PHP/" . phpversion();
			
			
			$body = "<div style='font-family: Courier New';>+---------------------------------------------------------------+<br />
	| ATEN&Ccedil;&Atilde;O! ESTA &Eacute; UMA MENSAGEM AUTOM&Aacute;TICA, FAVOR N&Atilde;O RESPONDER. |<br />
	+---------------------------------------------------------------+<br /><br /><br /></div>" . $body;
			mail($to, $subject, $body, $headers);
	}	

	function encode($VAR) 
	{
		$Acc = 0;
		for ($i = 0; $i < strlen($VAR);) {
			for ($j = 0; $j < 1000; $j++) {
				@$string[$Acc] .= $VAR[$i++];
			}
			$Acc++;
		}
		while (list($k, $v) = @each($string)) {
			for ($l = 0; $l < strlen($v); $l++) {
				$pos = $l + 1;
				//$fx = $this->cryptFuncao($pos);
				$fx = Helper::crpt($pos);
				@$hexa .= bin2hex(chr((ord($v[$l]) + $fx) % 256));
			}
		}
		return $hexa;
	}

    function decode($VAR) 
	{
        $Acc = 0;
		$Acc1=0;
		$chr="";
		$hexa="";
		$pos="";
		$fx="";
		$v="";
		$l="";
		
        for ($i = 0; $i < strlen($VAR);) 
		{
            for ($j = 0; $j < 2000; $j++) 
			{
                @$string[$Acc] .= $VAR[$i++];
            }
            $Acc++;
        }
        while (list($k, $v) = @each($string)) 
		{
            for ($l = 0; $l < strlen($v); $l++) 
			{
                $pos = ++$Acc1;
                $hexa = $v[$l] . $v[++$l];
                $fx = Helper::crpt($pos);
                //$fx = $this->cryptFuncao($pos);
                $chr .= chr(ord(pack("H*", $hexa)) - $fx % 256);
            }
            $Acc1 = 0;
        }
        return $chr;
    }
	
	function crpt($P) {
        $key = array(1, 1, 2, 3, 5, 8);
        $fx = ($key[0] * pow($P, 5)) + ($key[1] * pow($P, 4)) + ($key[2] * pow($P, 3)) + ($key[3] * pow($P, 2)) + ($key[4] * $P) + ($key[5]);
        return $fx;
    }	
	
	function checkemail($email)
	{		
		$regex = "/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,10})$/";
		$email = strtolower($email);
		return preg_match ($regex, $email);
	}
	
	function ckeckcpf($cpf)
	{
		$model = new Model();
		$sql = "select valida_cpf('".$cpf."')";
		$query = $model->pgqueryassoc($sql);
		return $query['valida_cpf'];		
	}	
	
}