<?php
echo $_SERVER['PHP_SELF'];
ini_set('display_errors',1);
error_reporting(E_ALL);
class Upload
{
	var $updirdefault = "/var/www/upload/tcc/extensaocultura/";
	
	function up()
	{
		if ($_FILES) 
		{
			if(isset($_FILES['plantabaixa']['tmp_name']))
			$this->uppdf();
			elseif(isset($_FILES['imgfile']['tmp_name']))
			$this->upimg();
		}
	}
	
	function uppdf()
	{
		$ext = end(explode(".", $_FILES['plantabaixa']['name']));
		$nomeImagem = date('Ymd') . date('His') . "." . $ext;	
		
		if (!move_uploaded_file($_FILES['plantabaixa']['tmp_name'], $this->updirdefault . $nomeImagem)) {
				echo "Erro ao subir imagem";
		} 
	}
	
	function upimg()
	{
		$ext = end(explode(".", $_FILES['imgfile']['name']));
		$nomeImagem = date('Ymd') . date('His') . "." . $ext;
		
		if (!move_uploaded_file($_FILES['imgfile']['tmp_name'], $this->updirdefault . $nomeImagem)) {
			echo "Erro ao subir imagem";
		} else {
			$type = str_replace("image/", "", $_FILES['imgfile']['type']);
			list($width, $height, $typeimg, $attr) = getimagesize($this->updirdefault . $nomeImagem);
			echo $type;
			if ($width > 1000) {
				if(!$this->make_thumb($this->updirdefault . $nomeImagem, $this->updirdefault . "mini".$nomeImagem, "800", $type))
				{
					echo "Erro ao criar thumb!";
				}				
			}
			$model = new Model();
			$_POST['titulofoto'] = $nomeImagem;
			$model->pgins('uniflocaisfotos');
		}
	}
	
	function make_thumb($src, $dest, $desired_width, $typeimg) {
        /* read the source image */
		echo $dest;
        switch ($typeimg) {
            case 'jpeg':
                $source_image = imagecreatefromjpeg($src);
                break;

            case 'png':
                $source_image = imagecreatefrompng($src);
                break;

            case 'gif':
                $source_image = imagecreatefromgif($src);
                break;
        }

        $width = imagesx($source_image);
        $height = imagesy($source_image);

        //find the "desired height" of this thumbnail, relative to the desired width 
        $desired_height = floor($height * ($desired_width / $width));

        //create a new, "virtual" image
        $virtual_image = imagecreatetruecolor($desired_width, $desired_height);

        //copy source image at a resized size 
        imagecopyresampled($virtual_image, $source_image, 0, 0, 0, 0, $desired_width, $desired_height, $width, $height);

        switch ($typeimg) {
            case 'jpeg':
            case 'jpg':
                imagejpeg($virtual_image, $dest);
                break;

            case 'png':
                imagepng($virtual_image, $dest);
                break;

            case 'gif':
                imagegif($virtual_image, $dest);
                break;
        }
    }
}
