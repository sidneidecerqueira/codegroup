﻿<?php 

class ClientesController
{
	var $template;
	var $model;
	
	function __construct()
	{
		
	}
	
	function index()
	{
		$o ="";
		$o.='<div class="col-sm-12">';
				
		require_once DIR_APP .'app/models/Cliente.php';
		$cli = new Cliente();
		$offset = 0;
		$limit = 5;
		$next = 2;
		$prev = 1;
		
		if(!empty($_GET['page']))
		{			
			$offset = ($_GET['page'] -1) * 5;
			$next = $_GET['page'] + 1;
			$prev = $_GET['page'] - 1;
		}
		
		$clientes_total = $cli->c_cli_all();
		$clientes = $cli->lista_cli_all($limit,$offset);	
		
		$o.='<div class="panel panel-success">';
				$o.='<div class="panel-heading">';
					$o.="<span>Clientes</span>";
				$o.='</div>';
				$o.='<!-- /.panel-heading -->';
				$o.='<div class="panel-body">';
					if($clientes[0]['id'])
					{
						$o.="<span>". $clientes_total ." Registro(s)</span>";
						$o.='<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">';
						$o.='<thead>';
						$o.='<tr>';
						$o.='<th>&nbsp;</th>';
						$o.='<th>ID</th>';
						$o.='<th>Nome</th>';
						$o.='<th>CPF</th>';
						$o.='<th>E-mail</th>';
						$o.='<th>Telefone</th>';
						$o.='<th>Endereço</th>';
						$o.='<th>Cadastrado em</th>';
						$o.='</tr>';
						$o.='</thead>';
						$o.='<tbody>';	
						foreach($clientes as $k => $v)
						{
							$o.="<tr class='odd gradeX'>";
							$o.='<td><a href="?c=ClientesController&m=editar_cliente&id='. $v['id'] .'"><span class="fa fa-edit"></span></a></td>';
							$o.="<td>{$v['id']}</td>";
							$o.="<td>{$v['nome']}</td>";
							$o.="<td>{$v['cpf']}</td>";
							$o.="<td>{$v['email']}</td>";
							$o.="<td>{$v['tel']}</td>";
							$o.="<td>{$v['endereco']}</td>";
							$o.="<td>{$v['dt_cadastro_br']}</td>";				
							$o.="</tr>";
						}			
						$o.='</tbody>';
						$o.='</table>';
						$o.='<!-- /.table-responsive -->'; 
					}
					else
					 {
					 	$o.='<h5>0 registro.</h5>';
					 }                          
				$o.='</div>';
			$o.='<!-- /.panel-body -->';
			$o.='</div>';
			$o.='<!-- /.panel -->';	
			$o.='<div class="col-sm-6">';
			$o.='<div id="dataTables-example_info" class="dataTables_info" role="status" aria-live="polite">Mostrando '. count($clientes) .' de '. $clientes_total .' Registros</div>';
		$o.='</div>';
										
		$o.='<div class="class="col-sm-6"">';
			$o.='<div id="dataTables-example_paginate" class="dataTables_paginate paging_simple_numbers">';
				$o.='<ul class="pagination">';	
				$pagLink = "<div class='pagination'>";	
				if(!empty($_GET['page']) and $_GET['page'] > 1)													
				$o.='<li id="dataTables-example_previous" class="paginate_button previous" aria-controls="dataTables-example" tabindex="0"><a href="?c=ClientesController&m=index&page='. $prev  .'">Prev</a></li>';
				for ($i=1; $i<=(ceil($clientes_total/5)); $i++) 
				{  
					$o.='<li class="paginate_button" aria-controls="dataTables-example" tabindex="0"><a href="?c=ClientesController&m=index&page='. $i .'">'. $i .'</a></li>'; 
				}				
				$o.='<li id="dataTables-example_next" class="paginate_button next" aria-controls="dataTables-example" tabindex="0"><a href="?c=ClientesController&m=index&page='. $next  .'">Next</a></li>';
				$o.='</ul>';
			$o.='</div>';
		$o.='</div>';
		
		$o.='</div>';
		$o.='<h1>&nbsp;</h1>';
		return $o;
	}
	
	function cadastrar_cliente()
	{
		$o ="";
		$o.='<div class="col-sm-12">';
			$o.='<form id="frm_cliente">';
				$o.='<div class="row">';
						$o.='<div class="col-sm-6 col-md-6 col-md-offset-1">';
							$o.='<div class="form-group">';
								$o.='<label>Informe o nome (*)</label>';
								$o.='<input class="form-control" type="text" name="nome" id="nome" required>';
								$o.='<p><small class="required-color">(* Campo obrigatório)</small></p>';
							$o.='</div>';
							$o.='<div class="form-group">';
								$o.= '<label>Informe o CPF (*)</label>';
								$o.='<input required class="form-control"  name="cpf" id="cpf" maxlength="11" onkeyup="this.value=this.value.replace(/[^0-9]/g,\'\');" autofocus>';
								$o.='<p><small class="required-color">(* Campo obrigatório)</small></p>';
							$o.='</div>';
							$o.='<div class="form-group">';
								$o.='<label>E-mail (*)</label>';
								$o.='<input class="form-control" type="text" name="email" id="email" required>';
								$o.='<p><small class="required-color">(* Campo obrigatório)</small></p>';
							$o.='</div>';
							$o.='<div class="form-group">';
								$o.='<label>Telefone</label>';
								$o.='<input class="form-control fone" type="text" name="tel" id="tel">';
								$o.='<p><small>Ex:(11)97177-8888</small></p>';
							$o.='</div>';
							$o.='<div class="form-group">';
								$o.='<label>Endereço</label>';
								$o.='<input class="form-control" type="text" name="endereco" id="endereco">';
								$o.='<p><small>Ex: Rua Estevão Soares, 1000 - Vila Rio Branco</small></p>';
							$o.='</div>';
							$o.='<div class="form-group">';
								$o.='<button class="btn btn-lg btn-success btn-block" type="button" onclick="cad();">Enviar</button>';
							$o.='</div>';
						$o.='</div>';
				$o.='</div>';							
			$o.='</form>';
		$o.='</div>';
		$o.='<h1>&nbsp;</h1>';
		return $o;
	}
	function editar_cliente()
	{
		$model = new Model();
		if(is_numeric($_GET['id']))
		{	 	
			$clientes = $model->pgquery("select *,to_char(dt_cadastro,'dd/mm/yyyy HH24:MI:SS') as dt_cadastro
										from cliente 
										where id = {$_GET['id']}");
		
			$o ="";
			$o.='<div class="col-sm-12">';
				$o.='<form id="frm_cliente_edt">';
				$o.= "<input type='hidden' name='id' value='". $_GET['id'] ."' class='form-control'>";
					$o.='<div class="row">';
							$o.='<div class="col-sm-6 col-md-6 col-md-offset-1">';
								$o.='<div class="form-group">';
									$o.='<label>Nome (*)</label>';
									$o.='<input class="form-control" type="text" name="nome" id="nome" value="'. $clientes[0]['nome'].'" required>';
									$o.='<p><small class="required-color">(* Campo obrigatório)</small></p>';
								$o.='</div>';
								$o.='<div class="form-group">';
									$o.= '<label>CPF (*)</label>';
									$o.='<input required class="form-control"  name="cpf" value="'. $clientes[0]['cpf'].'" id="cpf" maxlength="11" onkeyup="this.value=this.value.replace(/[^0-9]/g,\'\');" autofocus>';
									$o.='<p><small class="required-color">(* Campo obrigatório)</small></p>';
								$o.='</div>';
								$o.='<div class="form-group">';
									$o.='<label>E-mail (*)</label>';
									$o.='<input class="form-control" type="text" value="'. $clientes[0]['email'].'" name="email" id="email" required>';
									$o.='<p><small class="required-color">(* Campo obrigatório)</small></p>';
								$o.='</div>';
								$o.='<div class="form-group">';
									$o.='<label>Telefone</label>';
									$o.='<input class="form-control fone" type="text" name="tel" id="tel" value="'. $clientes[0]['tel'].'">';
									$o.='<p><small>Ex:(11)97177-8888</small></p>';
								$o.='</div>';
								$o.='<div class="form-group">';
									$o.='<label>Endereço</label>';
									$o.='<input class="form-control" type="text" name="endereco" id="endereco" value="'. $clientes[0]['endereco'].'">';
									$o.='<p><small>Ex: Rua Estevão Soares, 1000 - Vila Rio Branco</small></p>';
								$o.='</div>';
								$o.='<div class="row">';
									$o.='<div class="col-sm-6">';
										$o.='<div class="form-group">';
											$o.='<button class="btn btn-lg btn-success btn-block" type="button" onclick="edt();">Editar</button>';
										$o.='</div>';
									$o.='</div>';
									$o.='<div class="col-sm-6">';
										$o.='<div class="form-group">';
											$o.='<button class="btn btn-lg btn-alert btn-block" type="button" onclick="exl();">Excluir</button>';
										$o.='</div>';
									$o.='</div>';
								$o.='</div>';								
							$o.='</div>';
					$o.='</div>';					
					
													
				$o.='</form>';
			$o.='</div>';
			$o.='<h1>&nbsp;</h1>';
			return $o;
		}			
	}
	
	function cadastrar_cliente_bd()
	{
		require_once DIR_APP .'app/models/Cliente.php';
		$prepare = new Cliente();
		$prepare->prepare_cli_ins(array_values($_POST));
		echo $prepare->ret_prepare;
		unset($prepare);
	}
	function editar_cliente_bd()
	{
		require_once DIR_APP .'app/models/Cliente.php';
		$prepare = new Cliente();
		$prepare->prepare_cli_upd($_POST);
		echo $prepare->ret_prepare;
		unset($prepare);
	}
	function excluir_cliente_bd()
	{
		require_once DIR_APP .'app/models/Cliente.php';
		$prepare = new Cliente();
		$prepare->prepare_cli_del($_POST);
		echo $prepare->ret_prepare;
		unset($prepare);
	}
	
}